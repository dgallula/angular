export interface Cart {
  // id: string;
  // email: string;
  // password: string;
  // city: string;
  // street: string;
  // name: string;
  // lastname: string;
  // role: number;
}
