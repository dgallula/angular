export interface User {
  id: string;
  email: string;
  password: string;
  city: string;
  street: string;
  name: string;
  lastname: string;
  role: number;
}
