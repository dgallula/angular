export interface Product {
  id?: number;
  name?: string;
  price?: number;
  img?: string;
  category_id?: number;
  quantity?: number;
  total?: number;
  totalPrice?: number;
}
