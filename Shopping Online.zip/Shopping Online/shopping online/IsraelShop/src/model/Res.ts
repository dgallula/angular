export interface Res {
  success: Boolean;
  data: {};
  error: string;
}
